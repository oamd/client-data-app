package com.example.clientinfo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

data class ClientInfo(val name: String, val age: Int, val dateOfBirth: String)

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etName = findViewById<EditText>(R.id.etName)
        val etAge = findViewById<EditText>(R.id.etAge)
        val etDateOfBirth = findViewById<EditText>(R.id.etDateOfBirth)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)

        val database = Firebase.database
        val clientInfoRef = database.getReference("client_info")

        btnSubmit.setOnClickListener {
            val name = etName.text.toString()
            val age = etAge.text.toString().toInt()
            val dateOfBirth = etDateOfBirth.text.toString()

            val clientInfo = ClientInfo(name, age, dateOfBirth)
            clientInfoRef.push().setValue(clientInfo)
                .addOnSuccessListener {
                    Toast.makeText(this, "Information saved", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to save information", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
